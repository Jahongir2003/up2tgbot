## [AnyDLBot](https://telegram.dog/AnyDLBot) - Clone
---

An Open Source ALL-In-One Telegram RoBot, that can do lot of things.

**My Features**:

👉 All Supported Video Formats of https://rg3.github.io/youtube-dl/supportedsites.html

👉 Upload as file from any HTTP link

### Installation

#### The Easiest Way

**upgrade** your subscription for [@AnyDLBot](https://telegram.dog/AnyDLBot) without having to run anything on your own

#### The Easy Way

**Watch our Video for Create own Bot** - 👉 https://youtu.be/QkAkSLBgoYw

#### The Hard Way

```sh
virtualenv -p python3 VENV
. ./VENV/bin/activate
pip install -r requirements.txt
cp sample_config.py config.py
--- EDIT config.py values appropriately ---
python bot.py
```
## Our Telegram Channel and Group

* [TG Bots Updates](https://telegram.dog/TGBotsz)
* [InFoTel Paid Apps](https://telegram.dog/InFoTel14)
* [InFoTel Group](https://telegram.dog/InFoTelGroup)

## Credits, and Thanks to

* [Dan Tès](https://telegram.dog/haskell) for his [Pyrogram Library](https://github.com/pyrogram/pyrogram)
* [Yoily](https://telegram.dog/YoilyL) for his [UploaditBot](https://telegram.dog/UploaditBot)

- For FeedBack and Suggestions, please feel free to say in [@SpEcHlDe](https://telegram.dog/ThankTelegram)

#### LICENSE
- GPLv3
